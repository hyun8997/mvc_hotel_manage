package connection;

import java.sql.Connection;

import dao.AdminDAO;
import dao.HotelDAO;
import vo.AdminVO;
import vo.HotelVO;

public class TestMain {
	public static void main(String[] args) {
//		AdminVO avo = new AdminVO();
//		
//		avo.setAd_id("goott2");
//		avo.setAd_password("2345");
//		avo.setAd_name("g2");
//		avo.setAd_email("goott1@goott.net");
//		avo.setAd_tel("010-2313-3123");
//		avo.setAd_rank(1);
//		
//		AdminDAO adao = new AdminDAO();
//		adao.addAdmin(avo);
		
		
//		HotelVO hvo = new HotelVO();
//		HotelDAO hdao = new HotelDAO();
//		
//		String[] loc = {"종로구","중구","용산구","성동구","광진구","동대문구","중량구","성북구","강북구","도봉구","노원구","은평구",
//				"서대문구","마포구","양천구","강서구","구로구","금천구","영등포구","동작구","관악구","서초구","강남구",
//				"송파구","강동구"};	//25개임
//		
//		hvo.setAd_no(2);
//		
//		for(int i =0; i<25; i++){
//			hvo.setH_name("글래드 "+loc[i]);
//			hvo.setLoc(loc[i]+", 서울");
//			hvo.setH_conv("\r\n" + 
//					"비즈니스 비서 서비스, 비즈니스 센터, 모닝콜 서비스, 매일 하우스키핑, 팩스/복사, 컨시어지 서비스, 현장 환전, 세탁 서비스, 회의/연회 시설, 다국어를 구사하는 직원, 복사기 서비스, 24시간 보안, 컨퍼런스룸, 웨딩 서비스");
//			hvo.setH_comment("2층에 마련된 크리에이티브 라운지에는 PC, 스캐너, 레이저 프린터 등 다양한 비즈니스 시설이 구비되어 있으며 24시간 이용 가능합니다. 또한, 피트니스 센터에서도 24시간 무료로 운동을 하실 수 있습니다. 뿐만 아니라, 무료 주차장도 이용하실 수 있습니다. 전체 319개의 객실이 있으며 스탠다드부터 글래드 하우스까지 9가지 유형의 다양한 객실이 준비되어 있습니다. 블랙 앤 화이트의 깔끔한 인테리어의 객실 내에는 최고급 침구, 블루투스 스피커, LED TV가 마련되어 있으며 다양한 종류의 베개 중에 선택하실 수 있습니다. 또한 욕실 내에는 비데, 코튼 목욕 가운 등이 있으며 로비 층에 위치한 Greets에서는 7개의 라이브 스테이션에서 준비되는 뷔페와 한식 중식, 일식, 양식 단품 요리를 맛보실 수 있으며 영화 <킹스맨> 컨셉의 국내 최고 수준의 싱글 몰트 스카치 위스키를 보유한 BLACK BAR가 있습니다.");
//			hdao.addHotel(hvo);
//		}
		
		
		
		
	}
}
